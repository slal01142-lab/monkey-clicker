package com.example.monkeyclicker

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val status = TextView(this).apply { textSize = 18f; text = "Clicker: OFF" }
        val access = Button(this).apply {
            text = "1) Accessibility ON karo"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val toggle = Button(this).apply {
            text = "2) Start / Stop"
            setOnClickListener {
                ClickerService.enabled = !ClickerService.enabled
                status.text = if (ClickerService.enabled) "Clicker: ON" else "Clicker: OFF"
            }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
            addView(status); addView(access); addView(toggle)
        })
    }
}
