package com.example.monkeyclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Path
import android.os.Handler
import android.os.SystemClock
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.Point
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import java.util.concurrent.Executors

class ClickerService : AccessibilityService() {

    companion object {
        @Volatile var enabled = false           // MainActivity isse ON/OFF karta he

        const val REF_WIDTH = 1080.0            // jis screen width par templates liye the
        const val PLAY_THRESHOLD = 0.80         // Play button match
        const val HOLD_SCREEN_THRESHOLD = 0.70  // "Hold TO Jump" screen match
        const val COMPLETED_THRESHOLD = 0.70    // "LEVEL COMPLETED" screen match
        const val THEME_THRESHOLD = 0.60        // THEME (tree) tile match
        const val GETMORE_THRESHOLD = 0.70      // theme screen ka "GET MORE" button match
        const val BACK_THRESHOLD = 0.60         // back (left arrow) button match
        const val AD_THRESHOLD = 0.75           // ad screen ka "AD" label match
        const val CONTINUE_THRESHOLD = 0.70     // "DO YOU WANT TO CONTINUE ?" screen match
        const val NOTHANKS_THRESHOLD = 0.60     // "NO THANKS" match
        const val RESTART_THRESHOLD = 0.75      // GAME OVER screen ka RESTART button match

        // ---- ADS ----
        const val AD_MIN_WAIT_MS = 3000L        // ad dikhne ke itni der baad cross dhoondhna shuru
        const val AD_BACK_AFTER_MS = 45000L     // itni der me cross na mile to system Back dabao (last resort)
        const val CROSS_MIN_SCORE = 0.75        // X shape kitna pakka lage (0..1)
        const val UNKNOWN_BEFORE_CROSS = 3      // anjaan screen itni baar lagataar dikhe to cross dhoondho
        const val AD_POLL_MS = 1500L            // ad chalte waqt kitni der baad dobara dekhe
        val AD_WINDOW_REGEX = Regex(
            "AdActivity|\\.ads\\.|Interstitial|Rewarded|applovin|vungle|mbridge|pangle|unityads|ironsource|admob",
            RegexOption.IGNORE_CASE)
        val CLOSE_REGEX = Regex("close|dismiss|\\bskip\\b", RegexOption.IGNORE_CASE)

        const val IDLE_MS = 1100L               // kuch na mile to itni der baad dobara check
        const val AFTER_TAP_MS = 2000L          // Play / start tap ke baad wait
        const val AFTER_JUMP_MS = 1800L         // jump ke baad (hold time ke upar) wait

        // ---- CALIBRATION (jump ka hold time) ----
        const val BASE_HOLD_MS = 100.0          // minimum hold
        const val MS_PER_PX = 1.2               // har pixel doori ke liye kitne ms hold
        const val MAX_HOLD_MS = 2500.0
    }

    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private var playTpl: Mat? = null
    private var holdTpl: Mat? = null
    private var completedTpl: Mat? = null
    private var themeTpl: Mat? = null
    private var getMoreTpl: Mat? = null
    private var backTpl: Mat? = null
    private var adTpl: Mat? = null
    private var continueTpl: Mat? = null
    private var noThanksTpl: Mat? = null
    private var restartTpl: Mat? = null
    @Volatile private var lastWindowClass: String = ""
    private var adSeenAt = 0L
    private var unknownCount = 0

    override fun onServiceConnected() {
        OpenCVLoader.initLocal()
        playTpl = loadGray(R.drawable.play_template)
        holdTpl = loadGray(R.drawable.hold_template)
        completedTpl = loadGray(R.drawable.completed_template)
        themeTpl = loadGray(R.drawable.theme_template)
        getMoreTpl = loadGray(R.drawable.getmore_template)
        backTpl = loadGray(R.drawable.back_template)
        adTpl = loadGray(R.drawable.ad_template)
        continueTpl = loadGray(R.drawable.continue_template)
        noThanksTpl = loadGray(R.drawable.nothanks_template)
        restartTpl = loadGray(R.drawable.restart_template)
        handler.post { loop() }
    }

    private fun loadGray(resId: Int): Mat {
        val bmp = BitmapFactory.decodeResource(resources, resId)
        val rgba = Mat(); Utils.bitmapToMat(bmp, rgba)
        val gray = Mat(); Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
        return gray
    }

    // ---------- Main loop: screenshot -> decide -> act -> wait ----------
    private fun loop() {
        if (!enabled) { handler.postDelayed({ loop() }, IDLE_MS); return }

        takeScreenshot(Display.DEFAULT_DISPLAY, executor, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                var next = IDLE_MS
                try {
                    val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                    val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    result.hardwareBuffer.close()
                    if (bmp != null) next = process(bmp)
                } catch (e: Exception) {
                    // ignore, agle round me dobara try
                } finally {
                    handler.postDelayed({ loop() }, next)
                }
            }
            override fun onFailure(errorCode: Int) {
                handler.postDelayed({ loop() }, IDLE_MS)
            }
        })
    }

    /** Screen dekh kar sahi action karta he. Return: agla check kitni der baad (ms). */
    private fun process(bmp: Bitmap): Long {
        val rgba = Mat(); Utils.bitmapToMat(bmp, rgba)
        val gray = Mat(); Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
        val scale = bmp.width / REF_WIDTH
        try {
            // 0a) Monkey gir gaya: "DO YOU WANT TO CONTINUE ?" -> sirf NO THANKS dabao
            //     ("WATCH AD TO CONTINUE" button par tap nahi karta)
            match(gray, continueTpl!!, scale)?.let { (score, _) ->
                if (score >= CONTINUE_THRESHOLD) {
                    val m = match(gray, noThanksTpl!!, scale)
                    if (m != null && m.first >= NOTHANKS_THRESHOLD) {
                        tap(m.second.x.toFloat(), m.second.y.toFloat(), 60)
                    } else {
                        // fallback: screenshot wali fixed jagah
                        tap(bmp.width * 0.497f, bmp.height * 0.757f, 60)
                    }
                    return acted(AFTER_TAP_MS)
                }
            }

            // 0b) GAME OVER screen: sirf RESTART dabao ("Skip Level" par tap nahi karta)
            match(gray, restartTpl!!, scale)?.let { (score, p) ->
                if (score >= RESTART_THRESHOLD) {
                    tap(p.x.toFloat(), p.y.toFloat(), 60)
                    return acted(AFTER_TAP_MS)
                }
            }

            // 0) ADVERTISEMENT: har baar alag ad aata he, isliye cross ko 3 tareeke se dhoondhta he:
            //    (a) button ka naam (Close/Dismiss/Skip), (b) upar ke kono me "X" shape ki pehchan,
            //    (c) bahut lamba ad ho to system Back. Ad ke OPEN/install button par kabhi tap nahi.
            val inAd = AD_WINDOW_REGEX.containsMatchIn(lastWindowClass) ||
                (match(gray, adTpl!!, scale)?.first ?: 0.0) >= AD_THRESHOLD
            if (inAd) return handleAd(gray, scale)
            adSeenAt = 0L

            // 1) Main menu: Play button dikhe to tap
            match(gray, playTpl!!, scale)?.let { (score, p) ->
                if (score >= PLAY_THRESHOLD) {
                    tap(p.x.toFloat(), p.y.toFloat(), 60)
                    return acted(AFTER_TAP_MS)
                }
            }

            // 2) "Hold TO Jump" screen: screen par tap karke game shuru karo
            match(gray, holdTpl!!, scale)?.let { (score, _) ->
                if (score >= HOLD_SCREEN_THRESHOLD) {
                    tap(bmp.width / 2f, bmp.height * 0.63f, 60)
                    return acted(AFTER_TAP_MS)
                }
            }

            // 3) "LEVEL COMPLETED" screen: niche wale THEME (tree) tile par tap
            //    (NEXT button par tap nahi karta)
            match(gray, completedTpl!!, scale)?.let { (score, _) ->
                if (score >= COMPLETED_THRESHOLD) {
                    val m = match(gray, themeTpl!!, scale)
                    if (m != null && m.first >= THEME_THRESHOLD) {
                        tap(m.second.x.toFloat(), m.second.y.toFloat(), 60)
                    } else {
                        // fallback: screenshot wali fixed jagah
                        tap(bmp.width * 0.17f, bmp.height * 0.675f, 60)
                    }
                    return acted(AFTER_TAP_MS)
                }
            }

            // 4) THEME screen ("GET MORE" dikhe): upar left kone ka back button dabao
            match(gray, getMoreTpl!!, scale)?.let { (score, _) ->
                if (score >= GETMORE_THRESHOLD) {
                    val m = match(gray, backTpl!!, scale)
                    if (m != null && m.first >= BACK_THRESHOLD) {
                        tap(m.second.x.toFloat(), m.second.y.toFloat(), 60)
                    } else {
                        // fallback: screenshot wali fixed jagah (upar left)
                        tap(bmp.width * 0.127f, bmp.height * 0.105f, 60)
                    }
                    return acted(AFTER_TAP_MS)
                }
            }

            // 5) Game chal raha he: pillars dhoondo, doori ke hisab se hold karo
            val pillars = findPillars(rgba, scale)
            if (pillars.size >= 2) {
                val cur = pillars[0]
                val next = pillars[1]
                val distPx = ((next.x + next.width / 2.0) - (cur.x + cur.width / 2.0)) / scale
                val holdMs = minOf(MAX_HOLD_MS, BASE_HOLD_MS + MS_PER_PX * distPx).toLong()
                tap(bmp.width / 2f, bmp.height * 0.6f, holdMs)
                return acted(holdMs + AFTER_JUMP_MS)
            }
            // 6) Anjaan screen (jaise koi ad jo pehchana nahi gaya): lagataar dikhe to "X" dhoondho
            unknownCount++
            if (unknownCount >= UNKNOWN_BEFORE_CROSS) {
                findCrossButton(gray, scale)?.let { p ->
                    tap(p.x.toFloat(), p.y.toFloat(), 60)
                    return acted(AFTER_TAP_MS)
                }
            }
            return IDLE_MS
        } finally {
            rgba.release(); gray.release()
        }
    }

    // ---------- Image matching ----------
    private fun match(screen: Mat, tpl: Mat, scale: Double): Pair<Double, Point>? {
        val scaled = Mat()
        Imgproc.resize(tpl, scaled, Size(tpl.cols() * scale, tpl.rows() * scale))
        if (scaled.cols() > screen.cols() || scaled.rows() > screen.rows()) return null
        val res = Mat()
        Imgproc.matchTemplate(screen, scaled, res, Imgproc.TM_CCOEFF_NORMED)
        val mm = Core.minMaxLoc(res)
        val center = Point(mm.maxLoc.x + scaled.cols() / 2.0, mm.maxLoc.y + scaled.rows() / 2.0)
        scaled.release(); res.release()
        return Pair(mm.maxVal, center)
    }

    /** Pillars ki upar wali chamakdar hari patti dhoondta he. Left se right sorted. */
    private fun findPillars(rgba: Mat, scale: Double): List<Rect> {
        val rgb = Mat(); Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
        val hsv = Mat(); Imgproc.cvtColor(rgb, hsv, Imgproc.COLOR_RGB2HSV)
        val mask = Mat()
        Core.inRange(hsv, Scalar(30.0, 110.0, 140.0), Scalar(60.0, 255.0, 255.0), mask)
        val kernel = Imgproc.getStructuringElement(
            Imgproc.MORPH_RECT, Size(15.0 * scale, 7.0 * scale))
        Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_CLOSE, kernel)

        val contours = ArrayList<MatOfPoint>()
        Imgproc.findContours(mask, contours, Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
        val rects = contours.map { Imgproc.boundingRect(it) }.filter { r ->
            val w = r.width / scale
            val h = r.height / scale
            w in 80.0..450.0 && h in 25.0..140.0 && w / h >= 1.6
        }.sortedBy { it.x }
        rgb.release(); hsv.release(); mask.release()
        return rects
    }

    // ---------- Tap / Hold ----------
    private fun tap(x: Float, y: Float, durationMs: Long) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(1))
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun acted(ms: Long): Long { unknownCount = 0; return ms }

    private fun handleAd(gray: Mat, scale: Double): Long {
        unknownCount = 0
        val now = SystemClock.elapsedRealtime()
        if (adSeenAt == 0L) adSeenAt = now
        val elapsed = now - adSeenAt
        if (elapsed >= AD_MIN_WAIT_MS) {
            if (tryCloseViaNode()) { adSeenAt = 0L; return AFTER_TAP_MS }
            val p = findCrossButton(gray, scale)
            if (p != null) { tap(p.x.toFloat(), p.y.toFloat(), 60); return AFTER_TAP_MS }
            if (elapsed >= AD_BACK_AFTER_MS) {
                performGlobalAction(GLOBAL_ACTION_BACK)
                adSeenAt = now
            }
        }
        return AD_POLL_MS
    }

    /** Upar ke dono kono me chhota "X" (cross) dhoondhta he: safed/kala X, ya gol/chaukor button ke andar. */
    private fun findCrossButton(gray: Mat, scale: Double): Point? {
        val w = gray.cols(); val h = gray.rows()
        val bandH = (h * 0.14).toInt(); val bandW = (w * 0.25).toInt()
        val rois = listOf(Rect(w - bandW, 0, bandW, bandH), Rect(0, 0, bandW, bandH))
        var best: Point? = null
        var bestScore = 0.0
        for (roi in rois) {
            val sub = Mat(gray, roi)
            for (mode in 0..1) {
                val mask = Mat()
                if (mode == 0) Imgproc.threshold(sub, mask, 170.0, 255.0, Imgproc.THRESH_BINARY)       // chamakdar X
                else Imgproc.threshold(sub, mask, 85.0, 255.0, Imgproc.THRESH_BINARY_INV)              // kala X
                val contours = ArrayList<MatOfPoint>()
                Imgproc.findContours(mask, contours, Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE)
                for (c in contours) {
                    val r = Imgproc.boundingRect(c)
                    val rw = r.width / scale
                    val rh = r.height / scale
                    if (rw < 18 || rw > 110 || rh < 18 || rh > 110) continue
                    val ar = rw / rh
                    if (ar < 0.7 || ar > 1.4) continue
                    val score = crossScore(c, r)
                    if (score > bestScore) {
                        bestScore = score
                        best = Point(roi.x + r.x + r.width / 2.0, roi.y + r.y + r.height / 2.0)
                    }
                }
                mask.release()
            }
            sub.release()
        }
        return if (bestScore >= CROSS_MIN_SCORE) best else null
    }

    /** Shape "X" jaisa he? Dono diagonal bhari hon, beech me bhara ho, par kinaron ke beech wale hisse khaali hon. */
    private fun crossScore(c: MatOfPoint, r: Rect): Double {
        val w = r.width; val h = r.height
        val shape = Mat.zeros(h, w, CvType.CV_8UC1)
        Imgproc.drawContours(shape, listOf(c), -1, Scalar(255.0), -1, Imgproc.LINE_8,
            Mat(), 0, Point(-r.x.toDouble(), -r.y.toDouble()))
        fun hit(px: Int, py: Int): Boolean {
            for (dy in -1..1) for (dx in -1..1) {
                val xx = px + dx; val yy = py + dy
                if (xx in 0 until w && yy in 0 until h && shape.get(yy, xx)[0] > 0) return true
            }
            return false
        }
        val n = 12
        var diag = 0
        for (i in 0 until n) {
            val t = (i + 0.5) / n
            if (hit((t * w).toInt(), (t * h).toInt())) diag++
            if (hit((t * w).toInt(), ((1 - t) * h).toInt())) diag++
        }
        val diagScore = diag / (2.0 * n)
        val edgeHits = listOf(
            Pair(w / 2, (0.08 * h).toInt()), Pair(w / 2, (0.92 * h).toInt()),
            Pair((0.08 * w).toInt(), h / 2), Pair((0.92 * w).toInt(), h / 2)
        ).count { hit(it.first, it.second) }
        val center = hit(w / 2, h / 2)
        shape.release()
        return if (center && edgeHits <= 1) diagScore else 0.0
    }

    /** Ad ke andar "Close" / "Dismiss" / "Skip" naam wala clickable button dhoondh kar dabata he. */
    private fun tryCloseViaNode(): Boolean {
        val root = rootInActiveWindow ?: return false
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty()) {
            val n = queue.removeFirst()
            val label = "${n.contentDescription ?: ""} ${n.text ?: ""} ${n.viewIdResourceName ?: ""}"
            if (CLOSE_REGEX.containsMatchIn(label)) {
                var c: AccessibilityNodeInfo? = n
                while (c != null && !c.isClickable) c = c.parent
                if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it) }
        }
        return false
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            lastWindowClass = event.className?.toString() ?: ""
        }
    }
    override fun onInterrupt() {}
}
