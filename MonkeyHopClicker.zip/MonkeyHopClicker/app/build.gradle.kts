plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.monkeyclicker"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.monkeyclicker"
        minSdk = 30          // takeScreenshot ke liye Android 11+ chahiye
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    kotlinOptions { jvmTarget = "17" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("org.opencv:opencv:4.9.0")
}
