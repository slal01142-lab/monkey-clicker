Monkey Hop Clicker (Android 11+)

Phone se build (GitHub Actions):
1. github.com par account banao, naya repository banao.
2. Add file > Upload files > MonkeyHopClicker.zip upload karo (zip ko kholna nahi).
3. Add file > Create new file > naam: .github/workflows/build.yml  (build.yml ka text paste karo).
4. Actions tab > Build APK > Run workflow. 5-8 minute me APK ban jayegi.
5. Run kholo > Artifacts > MonkeyHopClicker-apk download karo, extract karke app-debug.apk install karo.

Phone me:
1. App kholo > "Accessibility ON karo" > Monkey Hop Clicker ko ON karo.
2. "Start / Stop" dabao, phir Monkey Hop kholo.

Tuning (ClickerService.kt, companion object): thresholds, BASE_HOLD_MS, MS_PER_PX, AD_MIN_WAIT_MS, CROSS_MIN_SCORE
